import React from 'react'
import '../../Components/Footer/Footer.scss'
export default function Footer() {
  return (
    <div className="footer">
        <div className="copyright-wrap">
            <p>© All Rights are Reserved. Bigdaddyvilla.com</p>
        </div>
    </div>
  )
}
